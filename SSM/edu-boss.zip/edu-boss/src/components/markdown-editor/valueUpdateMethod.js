export default ['insertText', 'setValue', 'setMarkdown', 'setHtml', 'reset']
